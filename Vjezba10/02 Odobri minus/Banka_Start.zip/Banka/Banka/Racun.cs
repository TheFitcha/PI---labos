﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Banka
{
    public class Racun
    {
        public string IBAN { get; set; }
        public double Stanje { get; set; }
    }
}
