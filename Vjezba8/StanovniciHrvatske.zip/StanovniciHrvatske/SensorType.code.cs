﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StanovniciHrvatske
{
    public partial class SensorType
    {
        public override string ToString()
        {
            return Type;
        }
    }
}
