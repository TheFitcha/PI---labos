﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StanovniciHrvatske
{
    public partial class MeasurementUnit
    {
        public override string ToString()
        {
            return Name;
        }
    }
}
